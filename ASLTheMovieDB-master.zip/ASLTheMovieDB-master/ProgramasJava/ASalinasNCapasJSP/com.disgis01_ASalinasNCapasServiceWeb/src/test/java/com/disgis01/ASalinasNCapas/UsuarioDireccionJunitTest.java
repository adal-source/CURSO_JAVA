/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.disgis01.ASalinasNCapas;

import org.springframework.boot.test.context.SpringBootTest;

/**
 *
 * @author Alien 1
 */
@SpringBootTest
public class UsuarioDireccionJunitTest {
    
}
