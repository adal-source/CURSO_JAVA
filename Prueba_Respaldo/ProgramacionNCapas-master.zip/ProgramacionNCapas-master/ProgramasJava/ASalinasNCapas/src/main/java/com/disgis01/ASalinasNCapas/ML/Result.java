/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.disgis01.ASalinasNCapas.ML;

import java.util.List;

/**
 *
 * @author Alien 1
 */
public class Result {

    public boolean correct;
    public String errorMasassge;
    public Exception ex;
    public Object object;
    public List<Object> objects;
}
