/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.disgis01.ASalinasNCapas.ML;

/**
 *
 * @author Alien 1
 */
public class Roll {
    
    private int IdRoll;
    private String NombreRoll;

    public int getIdRoll() {
        return IdRoll;
    }

    public void setIdRoll(int IdRoll) {
        this.IdRoll = IdRoll;
    }

    public String getNombreRoll() {
        return NombreRoll;
    }

    public void setNombreRoll(String NombreRoll) {
        this.NombreRoll = NombreRoll;
    }
    
}
