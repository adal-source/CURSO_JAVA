package com.disgis01.ASalinasNCapas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ASalinasNCapasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ASalinasNCapasApplication.class, args);
	}

}
