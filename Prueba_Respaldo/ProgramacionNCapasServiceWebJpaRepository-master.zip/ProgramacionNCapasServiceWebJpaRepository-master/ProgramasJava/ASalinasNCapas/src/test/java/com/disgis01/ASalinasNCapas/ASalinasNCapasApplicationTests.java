package com.disgis01.ASalinasNCapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ASalinasNCapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
